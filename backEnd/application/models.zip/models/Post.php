<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Post extends CI_Model {

    public function __construct() {
        parent::__construct();
        
        // Load the database library
        $this->load->database();
        $this->load->model('comment');
        $this->userTbl = 'ci_posts';

    }


    public function insert($data)
    {
    	 //add created and modified date if not exists
        if(!array_key_exists("created_date", $data)){
            $data['created_date'] = date("Y-m-d H:i:s");
        }
        if(!array_key_exists("modified_date", $data)){
            $data['modified_date'] = date("Y-m-d H:i:s");
        }
        
        //insert user data to users table
        $insert = $this->db->insert($this->userTbl, $data);
        
        //return the status
        return $insert?$this->db->insert_id():false;
    }

    public function getall($id)
    {
    	$this->db->select('*');
    	$this->db->where('user_id',$id);
    	$query=$this->db->get($this->userTbl);

    	if($query->num_rows()>0)
    	{
	 		$result=$query->result_array();

	 		foreach($result as $index=>$row)
	 		{
	 			$this->db->select('*');
	 			$this->db->where('postid',$row['post_id']);
	 			$attachmentQuery=$this->db->get('post_attachments');
	 			if($attachmentQuery->num_rows()>0)
	 			{
	 				$result[$index]['attachments']=$attachmentQuery->result_array();	
	 			}


	 			$commentQuery=$this->comment->getByPost($row['post_id']);

	 			if($commentQuery)
	 			{
	 				$result[$index]['comments']=$commentQuery->result_array();	
	 			}

	 			


	 		}   		
	 		return $result;
    	}
    	else
    	{
    		return false;
    	}

    }

    public function deletePost($id,$postid)
    {
    	$this->db->where('user_id',$id);
    	$this->db->where('post_id',$postid);
    	$result=$this->db->get($this->userTbl);

    	if($result->num_rows()>0)
    	{
    		$this->db->where('user_id',$id);
    	$this->db->where('post_id',$postid);
    		$this->db->delete($this->userTbl);
    		return true;
    	}
    	else
    	{
    		return false;
    	}
    		

    }

    public function update($id,$postid,$userdata){

    	$this->db->where('user_id',$id);
    	$this->db->where('post_id',$postid);
    	$result=$this->db->get($this->userTbl);

    	if($result->num_rows()>0)
    	{
    		$this->db->where('user_id',$id);
    	$this->db->where('post_id',$postid);
    	$this->db->update($this->userTbl,$userdata);

    	return true;

    	}else{
    		return false;
    	}

    }
    
    	
    	public function delete($post)
    	{
    		$this->db->where('post_id',$post);
    		$this->db->delete($this->userTbl);
    	}


    	public function saveImages($data)
    	{
    		$this->db->insert_batch('post_attachments',$data);
    	}

    	public function updateCommentCount($post_id)
    	{
    	$this->db->select('comment_count');
    	$this->db->where('post_id',$post_id);
    	$query=$this->db->get($this->userTbl);


    	if($query->num_rows()>0)
    	{
    		$userData['comment_count']=((int)$query->row()->comment_count)+1;
    		$this->db->where('post_id',$post_id);
    		$this->db->update($this->userTbl,$userData);
    	}
    	else
    	{
    		return false;
    	}


    	}


}