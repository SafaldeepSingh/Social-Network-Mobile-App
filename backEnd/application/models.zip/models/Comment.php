<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Comment extends CI_Model {

	  public function __construct() {
        parent::__construct();
        
        // Load the database library
        $this->load->database();
        
        $this->userTbl = 'ci_comments';
          
    }


        public function insert($data){

        	if(!array_key_exists("created_date", $data)){
            $data['created_date'] = date("Y-m-d H:i:s");
        	}


        	if(!array_key_exists("modified_date", $data)){
            $data['modified_date'] = date("Y-m-d H:i:s");
       	 	}

       	 	$insert = $this->db->insert($this->userTbl, $data);
       	 	

       	 	 return $insert?$this->db->insert_id():false;


        }

        public function getByPost($post_id)
        {
        	$this->db->select('*');
    	$this->db->where('post',$post_id);
    	$query=$this->db->get($this->userTbl);

    	if($query->num_rows()>0)
    	{
    		return $query;
    	}
    	else
    	{
    		return false;
    	}


        }
    
}