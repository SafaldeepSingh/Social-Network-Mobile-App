<?php
use Restserver\Libraries\REST_Controller;
if (!defined('BASEPATH')) exit('No direct script access allowed');
date_default_timezone_set('Asia/Kolkata');

// Load the Rest Controller library
require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';


class Users extends REST_Controller {

    public function __construct() { 
        parent::__construct();
        
        // Load the user model
        $this->load->model('user');
         $this->load->helper('jwt');
        $this->load->model('keys/jwt_token_model','jwtModel');
        
    }
    
  
    public function detail_get($id = 0) {
        // Returns all the users data if the id not specified,
        // Otherwise, a single user will be returned.
        $con = $id?array('id' => $id):'';
        $users = $this->user->getRows($con);
        
        // Check if the user data exists
        if(!empty($users)){
            // Set the response and exit
            //OK (200) being the HTTP response code
            $this->response($users, REST_Controller::HTTP_OK);
        }else{
            // Set the response and exit
            //NOT_FOUND (404) being the HTTP response code
            $this->response([
                'status' => FALSE,
                'message' => 'No user was found.'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }
    
    public function update_put() {

        $id = $this->put('id');

        $jwt=$this->input->get_request_header('Authorization');
        
        if($jwt)
        {
         


            $data=validateJWT($id,$jwt);

            if($data)
            {
                if($id==$data->id)
                {
                    $first_name = strip_tags($this->put('first_name'));
        $last_name = strip_tags($this->put('last_name'));
        $email = strip_tags($this->put('email'));
        $password = $this->put('password');
        $phone = strip_tags($this->put('phone'));
        
        // Validate the post data
        if(!empty($id) && (!empty($first_name) || !empty($last_name) || !empty($email) || !empty($password) || !empty($phone))){
            // Update user's account data
            $userData = array();
            if(!empty($first_name)){
                $userData['first_name'] = $first_name;
            }
            if(!empty($last_name)){
                $userData['last_name'] = $last_name;
            }
            if(!empty($email)){
                $userData['email'] = $email;
            }
            if(!empty($password)){
                $userData['password'] = md5($password);
            }
            if(!empty($phone)){
                $userData['phone'] = $phone;
            }
            $update = $this->user->update($userData, $id);
            
            // Check if the user data is updated
            if($update){

                $jwtDetails=createToken($id,$email,$first_name,$last_name,$phone,getSecretKey($id));
                $jwt=$jwtDetails['key'];

                    $jwtData=array(
                        'token' => $jwt,
                        'created' => $jwtDetails['iat'],
                        'expires' => $jwtDetails['exp']
                    );

                $this->jwtModel->updateToken($id,$jwtData);

                // Set the response and exit
                $this->response([

                    'status' => TRUE,
                    'message' => 'The user info has been updated successfully.',
                    'jwt' => $jwt
                ], REST_Controller::HTTP_OK);
            }else{
                // Set the response and exit
                $this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
            }
        }else{
            // Set the response and exit
            $this->response("Provide at least one user info to update.", REST_Controller::HTTP_BAD_REQUEST);
        }
                }
            }
            else
            {
             $this->response(array('status'=>'Forbidden'), REST_Controller::HTTP_UNAUTHORIZED);
            }      
        

            // Get the post data
        
        }
        else{
             $this->response([
                    'status' => FALSE,
                    'message' => 'Forbidden'
                ], REST_Controller::HTTP_UNAUTHORIZED);
        }        

        
    }

}