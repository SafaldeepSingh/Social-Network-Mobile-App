<?php
use Restserver\Libraries\REST_Controller;
if (!defined('BASEPATH')) exit('No direct script access allowed');
date_default_timezone_set('Asia/Kolkata');

// Load the Rest Controller library
require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';


class Comments extends REST_Controller {

    public function __construct() { 
        parent::__construct();
        
        // Load the user model
        $this->load->model('comment');
          $this->load->model('post');
         $this->load->helper('jwt');
         $this->load->helper('file_upload');
        $this->load->model('keys/jwt_token_model','jwtModel');
        
    }

    public function add_post()
    {
    	 $jwt=$this->input->get_request_header('Authorization');

    	 if($jwt)
        {

        	$id=$this->post('user_id');
        	$data=validateJWT($id,$jwt);

        	 if($data)
            {
            	 if((int)$id==(int)$data->id)
                {
                	$userData['comment_text']=strip_tags($this->post('comment'));

                	$parent=strip_tags($this->post('parent_comment'));

                	if(!empty($parent))
                	{
						$userData['parent']=$parent;                		
                	}
                	else
                	{
                	$userData['parent']=0;                			
                	}

                	$userData['user_id']=$id;
                	$userData['post']=strip_tags($this->post('post_id'));

                	$insert = $this->comment->insert($userData);

                	if($insert)
                	{
                		$this->post->updateCommentCount($userData['post']);	
                		 $responseData['comment_id'] = $insert;

                		  $this->response([
                        'status' => TRUE,
                        'message' => 'The comment has been added successfully.',
                        'data' => $responseData
                    ], REST_Controller::HTTP_OK);



                	}
                	else
                	{
                		$this->response("Some problem occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
                	}


                	

                }
                else
                {
                	$this->response(array('status'=>'Forbidden'), REST_Controller::HTTP_UNAUTHORIZED);
                }
            }
            else
            {
            	$this->response(array('status'=>'Forbidden'), REST_Controller::HTTP_UNAUTHORIZED);
            }

        }
        else
        {
        	$this->response(array('status'=>'Forbidden, No JWT present'), REST_Controller::HTTP_UNAUTHORIZED);
        }
    }



}